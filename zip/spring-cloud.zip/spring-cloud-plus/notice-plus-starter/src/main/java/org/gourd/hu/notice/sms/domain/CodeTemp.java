package org.gourd.hu.notice.sms.domain;

import lombok.Data;

@Data
public class CodeTemp {

    private String code;

}
