/**
 * 接口出参对象包
 *
 * @author tiffin.zhang
 *
 */
package org.gourd.hu.rbac.model.vo;