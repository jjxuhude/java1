/**
 * 实体类包,和数据库一一对应
 *
 * @author tiffin.zhang
 *
 */
package org.gourd.hu.rbac.model.entity;