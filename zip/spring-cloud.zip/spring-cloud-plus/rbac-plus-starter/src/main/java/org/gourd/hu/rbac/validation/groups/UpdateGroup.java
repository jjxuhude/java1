package org.gourd.hu.rbac.validation.groups;

import javax.validation.groups.Default;

/**
 * @Description 更新分组
 * @Author gourd.hu
 * @Date 2020/7/23 14:10
 * @Version 1.0
 */
public interface UpdateGroup extends Default {
}
