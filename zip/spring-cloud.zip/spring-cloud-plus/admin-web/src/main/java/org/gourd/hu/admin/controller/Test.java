package org.gourd.hu.admin.controller;

import java.util.ArrayList;
import java.util.List;

public class Test {
    private static final List<String> args11 = List.of("a","b");
    public static void main(String[] args) {
        args11.add("a");
        System.out.println(args11);
    }
}
