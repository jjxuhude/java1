package org.gourd.hu.sub.service;

import org.gourd.hu.sub.fallback.SubFallbackFactory;
import org.gourd.hu.sub.response.BaseResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * sub服务API调用类
 * contextId属性： 解决相同name不同client不同配置的问题
 * feign不支持下划线"_"，支持"-",否则报错：Service id not legal hostname
 * @author gourd
 */
@FeignClient(name = "admin",fallbackFactory = SubFallbackFactory.class)
public interface SubAdminApi {


    @GetMapping("/test/log")
    BaseResponse logTest(@RequestParam String param);

    @GetMapping("/test/cache")
    public BaseResponse cacheTest();

    @GetMapping("/test/retry")
    public BaseResponse retryTest();

    @GetMapping("/test/log-level")
    public BaseResponse logLevelTest();

}