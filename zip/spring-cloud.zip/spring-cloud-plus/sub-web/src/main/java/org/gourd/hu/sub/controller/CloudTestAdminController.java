package org.gourd.hu.sub.controller;

import lombok.extern.slf4j.Slf4j;

import org.gourd.hu.sub.response.BaseResponse;
import org.gourd.hu.sub.service.SubAdminApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * spring cloud  测试提供者
 * @author gourd
 */
@Slf4j
@RestController
@RequestMapping("/test/admin")
public class CloudTestAdminController {
    @Autowired
    private SubAdminApi subAdminApi;
    @GetMapping("/log/test")
    public BaseResponse logTest(@RequestParam String param) {
        log.info("连接成功:"+ param );
        return subAdminApi.logTest(param);
    }
    @GetMapping("/cache/test")
    public BaseResponse cacheTest(@RequestParam Long id) {
        log.info("连接成功:"+ id );
        return subAdminApi.cacheTest();
    }
    @GetMapping("/level/test")
    public BaseResponse logLevelTest(String name) {
        log.info("连接成功:"+ name);
        return subAdminApi.logLevelTest();
    }
    @GetMapping("/retry/test")
    public BaseResponse retryTest(String name) {
        log.info("连接成功:"+ name);
        return subAdminApi.retryTest();
    }
}
