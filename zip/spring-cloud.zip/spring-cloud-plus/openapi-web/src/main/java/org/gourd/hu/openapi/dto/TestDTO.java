package org.gourd.hu.openapi.dto;

import lombok.Data;

/**
 * @Description 测试
 * @Author gourd
 * @Date 2020/4/2 14:26
 * @Version 1.0
 */
@Data
public class TestDTO {

    private String name;

    private Long id;
}
